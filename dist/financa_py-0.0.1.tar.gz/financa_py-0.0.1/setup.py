from setuptools import setup, find_packages



setup(name='financa_py',
    version='0.0.1',
    license='MIT License',
    author='Douglas Faria',
    long_description='readme',
    long_description_content_type="text/markdown",
    author_email='douglasfariasil14@gmail.com',
    keywords='financa_py',
    description=u'este é meu primeiro projeto no pypi',
    packages=['financa_py'],
    )